import React from 'react';

export function Header({darkMode, setDarkMode}) {
    // pull out props
    console.log(darkMode)
    console.log(setDarkMode)
    return <header>
        <h1>ABC Inc.</h1>
        <div>
            {/* attach click handler */}
            <button className={`material-icons ${darkMode ? 'someDarkClass' : 'someLightClass'}`} onClick ={()=>{
console.log('firing')
  setDarkMode()
}}>
                {darkMode ? "dark_mode" : "light_mode"}
                dark_mode
            </button>
            {/* attach click handler */}
            <button className="material-icons" >
                text_fields
            </button>
        </div>
    </header>
}