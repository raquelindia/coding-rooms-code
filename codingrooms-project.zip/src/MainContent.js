import React from 'react';

export function MainContent() {
    
    return <main>
        <section>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Animi repudiandae doloremque sunt molestias laudantium esse voluptas magni dolorum laborum! Consequatur debitis maiores molestiae molestias expedita at dolore similique iure autem.</p>
            <p>Sunt veritatis amet minus a numquam. A animi repellat hic ea dolorem eius consequuntur obcaecati, corrupti, ipsam dolor perspiciatis quam nihil blanditiis iusto! Qui impedit, a architecto id in quod.</p>
            <p>Expedita aperiam itaque dolor odio iure velit laboriosam inventore ducimus neque quos tempore, similique possimus. Animi ducimus inventore qui dicta enim fuga adipisci aperiam reiciendis, autem vel cum earum quis!</p>
            <p>A, recusandae. Quam eligendi quia sed nihil distinctio illum maxime. Ullam ut impedit totam similique at harum atque voluptatum consequatur molestias, labore voluptate dolores recusandae ad a nostrum ducimus minima.</p>
            <p>Quisquam modi aut atque iusto eius! Delectus voluptas ratione atque corporis nesciunt est eligendi consequatur dolorum provident, quibusdam voluptatum voluptate ad similique vel? Possimus eum voluptate animi, quas numquam quidem?</p>
        </section>
        <section>
            <p>Sunt, neque harum est, ex iusto cupiditate possimus repellendus itaque incidunt rerum voluptatibus nam quae. Optio, qui deserunt? Consectetur, in. Odio beatae culpa obcaecati soluta mollitia excepturi at odit laboriosam?</p>
            <p>Animi numquam iure saepe sit debitis, expedita velit. Amet ipsum totam, dicta omnis laborum nemo et earum, voluptas assumenda quisquam, illum ad! Aspernatur, veniam repellendus! Ut eveniet tempore blanditiis praesentium?</p>
            <p>Quasi at adipisci atque doloremque dolorem vitae. Mollitia illo enim quo perspiciatis sapiente itaque. Ducimus eius excepturi dicta eum quam ipsum odit iste illum in, eaque sint, officiis et tenetur!</p>
            <p>Quo quae reprehenderit ex assumenda inventore ducimus consectetur natus possimus consequuntur mollitia fugit, excepturi sint soluta, libero quibusdam laboriosam eligendi placeat. Esse eligendi sint unde repudiandae, suscipit laborum accusamus animi!</p>
            <p>Ab, nobis minima consectetur modi vel ipsum doloremque provident similique suscipit voluptates dolor. Non, ipsam debitis unde necessitatibus earum nesciunt, itaque recusandae eos maxime in quia placeat velit fugiat fugit.</p>
        </section>
        <section>
            <p>Aperiam, quasi! Minus consectetur eos repellat! Magni placeat alias libero facere ducimus. Fugiat rem similique ad amet ex fugit iure facere quos dolores ipsa obcaecati, sunt, perspiciatis vitae! Sed, optio?</p>
            <p>Minima, sit neque adipisci laudantium quibusdam inventore recusandae ullam mollitia consequuntur possimus nemo exercitationem dignissimos nobis et odit. Molestiae consequuntur deleniti enim ratione magni porro ducimus? Quo ab amet ad!</p>
            <p>Beatae dolorem molestias reprehenderit fugit perferendis tempora doloribus quaerat porro facilis ea quisquam aut distinctio rerum eveniet vel dicta quod eaque impedit deleniti inventore necessitatibus, consequatur explicabo! Unde, quod eaque?</p>
            <p>Aspernatur aliquid incidunt distinctio provident sit, praesentium error repellendus veniam doloremque deserunt necessitatibus ad velit quidem iusto qui adipisci est laborum et vero laudantium animi magnam, eligendi non unde. Tempore.</p>
            <p>Natus esse fugit iusto quia voluptatum assumenda sequi nam, nobis numquam amet optio aperiam delectus odit id rerum non? Facilis saepe voluptatibus illo, totam quaerat nisi quos maiores quod blanditiis.</p>
        </section>
    </main>
}