import React, { useState, useCallback } from 'react';
import { MainContent } from './MainContent.js';
import { Header } from './Header.js';



export function App() {
    // initialize state
    const [darkMode, setDarkMode] = useState(false);
    const func = useCallback(()=>{
        console.log(darkMode)
setDarkMode(!darkMode)
},[darkMode,setDarkMode])
    return <div id='app' aria-label='app' className= {'darkMode ? dark_mode : light_mode'} /* edit className and add style */>
        {<Header darkMode={darkMode} setDarkMode={func}/> /* pass above-defined state as props */}
        <Header/>

        <aside>
            <button>Home</button>
            <button>About</button>
            <button>Contact</button>
            <button>Company</button>
        </aside>
        <MainContent />
        <footer></footer>
    </div>
}